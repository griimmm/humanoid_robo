// generated from rosidl_generator_c/resource/idl.h.em
// with input from geometry_msgs:msg/Wrench.idl
// generated code does not contain a copyright notice

#ifndef GEOMETRY_MSGS__MSG__WRENCH_H_
#define GEOMETRY_MSGS__MSG__WRENCH_H_

#include "geometry_msgs/msg/detail/wrench__struct.h"
#include "geometry_msgs/msg/detail/wrench__functions.h"
#include "geometry_msgs/msg/detail/wrench__type_support.h"

#endif  // GEOMETRY_MSGS__MSG__WRENCH_H_
